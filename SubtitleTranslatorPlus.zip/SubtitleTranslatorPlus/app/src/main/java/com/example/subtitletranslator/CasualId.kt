package com.example.subtitletranslator

/**
 * Mengubah hasil terjemahan Indonesia yang kaku menjadi lebih santai/sehari-hari,
 * dengan mengganti kata-kata baku yang jarang dipakai saat ngobrol.
 * Hanya mengganti kata utuh dan menjaga huruf besar di awal kata.
 */
object CasualId {

    // Urutan penting: frasa panjang dulu, baru kata tunggal.
    private val rules: List<Pair<Regex, String>> = listOf(
        "tidak apa-apa" to "nggak apa-apa",
        "terima kasih banyak" to "makasih banyak",
        "terima kasih" to "makasih",
        "anda semua" to "kalian semua",
        "seperti ini" to "kayak gini",
        "seperti itu" to "kayak gitu",
        "sedang" to "lagi",
        "anda" to "kamu",
        "saya" to "aku",
        "tidak" to "nggak",
        "sudah" to "udah",
        "telah" to "udah",
        "akan" to "bakal",
        "hanya" to "cuma",
        "saja" to "aja",
        "tetapi" to "tapi",
        "namun" to "tapi",
        "bagaimana" to "gimana",
        "mengapa" to "kenapa",
        "ingin" to "mau",
        "seperti" to "kayak",
        "begitu" to "gitu",
        "sangat" to "bener-bener",
        "kepada" to "ke",
        "benar-benar" to "bener-bener"
    ).map { (from, to) -> Regex("\\b" + Regex.escape(from) + "\\b", RegexOption.IGNORE_CASE) to to }

    private val apakah = Regex("\\bapakah\\s+", RegexOption.IGNORE_CASE)

    fun convert(text: String): String {
        if (text.isBlank()) return text
        var out = text
        for ((re, to) in rules) {
            out = re.replace(out) { m ->
                if (m.value.first().isUpperCase()) to.replaceFirstChar { it.uppercase() } else to
            }
        }
        out = apakah.replace(out, "")
        if (text.first().isUpperCase() && out.isNotEmpty()) {
            out = out.replaceFirstChar { it.uppercase() }
        }
        return out
    }
}
