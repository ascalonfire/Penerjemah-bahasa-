package com.example.subtitletranslator

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Memperhalus hasil terjemahan mesin menjadi bahasa Indonesia santai lewat Gemini API.
 * Gagal/terlambat/kena batas => diam saja, terjemahan ML Kit tetap dipakai.
 */
class GeminiRefiner(
    private val apiKey: String,
    private val model: String,
    private val glossary: String = "",
    private val onError: (String) -> Unit
) {
    enum class State { OK, LIMIT, ERROR }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val inFlight = AtomicBoolean(false)

    @Volatile private var pausedUntil = 0L
    @Volatile private var disabled = false
    @Volatile private var lastCallAt = 0L
    private var errorShown = false

    private val systemPrompt: String get() = basePrompt + glossaryPart()

    private fun glossaryPart(): String {
        val lines = glossary.lines().map { it.trim() }.filter { it.contains("=") }
        if (lines.isEmpty()) return ""
        return " Glosarium wajib (tulis persis seperti ini, jangan diubah): " + lines.joinToString("; ")
    }

    /** Status untuk titik indikator di panel kontrol. */
    fun state(): State = when {
        disabled -> State.ERROR
        SystemClock.elapsedRealtime() < pausedUntil -> State.LIMIT
        else -> State.OK
    }

    private val basePrompt =
        "Kamu penerjemah subtitel video ke bahasa Indonesia sehari-hari yang santai dan natural, " +
        "seperti orang ngobrol (aku/kamu, nggak, udah), tapi tetap jelas dan tidak kasar. " +
        "Pertahankan makna asli, jangan menambah informasi, dan jaga agar singkat seperti subtitel. " +
        "Gunakan konteks kalimat sebelumnya untuk menebak siapa/apa yang dimaksud. " +
        "Keluarkan HANYA hasil terjemahan, tanpa penjelasan, tanpa tanda kutip."

    /** Dipanggil dari main thread. onDone dipanggil di main thread hanya jika berhasil. */
    fun refine(
        sourceLang: String,
        source: String,
        draft: String,
        context: List<String>,
        onDone: (String) -> Unit
    ) {
        val now = SystemClock.elapsedRealtime()
        if (disabled || now < pausedUntil) return
        if (now - lastCallAt < MIN_GAP_MS) return
        if (!inFlight.compareAndSet(false, true)) return // satu permintaan sekali waktu
        lastCallAt = now

        executor.execute {
            try {
                val result = call(sourceLang, source, draft, context)
                if (!result.isNullOrBlank() && result.length <= draft.length * 3 + 120) {
                    main.post { onDone(result) }
                }
            } finally {
                inFlight.set(false)
            }
        }
    }

    private fun call(lang: String, source: String, draft: String, context: List<String>): String? {
        val userText = buildString {
            append("Bahasa sumber: ").append(lang).append('\n')
            if (context.isNotEmpty()) {
                append("Kalimat sebelumnya:\n")
                context.forEach { append("- ").append(it).append('\n') }
            }
            append("Teks: ").append(source).append('\n')
            append("Draf mesin (bisa salah): ").append(draft)
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", JSONArray().put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userText)))
            ))
            .put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", 200))
            .toString()

        var conn: HttpURLConnection? = null
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 4000
                readTimeout = 6000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            conn.outputStream.use { it.write(body.toByteArray()) }

            when (val code = conn.responseCode) {
                200 -> {
                    val json = JSONObject(conn.inputStream.bufferedReader().readText())
                    val parts = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                    return sb.toString().trim().trim('"', '“', '”').replace("\n", " ").trim()
                }
                429 -> {
                    pausedUntil = SystemClock.elapsedRealtime() + 60_000
                    reportOnce("Batas Gemini tercapai, memakai terjemahan biasa sebentar")
                }
                400, 401, 403, 404 -> {
                    disabled = true
                    reportOnce("Gemini ditolak (kode $code). Cek API key dan nama model")
                }
                else -> pausedUntil = SystemClock.elapsedRealtime() + 10_000
            }
        } catch (e: Exception) {
            pausedUntil = SystemClock.elapsedRealtime() + 5_000 // jaringan bermasalah
        } finally {
            conn?.disconnect()
        }
        return null
    }

    private fun reportOnce(msg: String) {
        if (errorShown) return
        errorShown = true
        main.post { onError(msg) }
    }

    fun close() = executor.shutdownNow()

    companion object {
        private const val MIN_GAP_MS = 1200L

        /** Uji key dan model dengan satu permintaan kecil. Hasil (teks pesan) dikirim di main thread. */
        fun test(apiKey: String, model: String, onResult: (String) -> Unit) {
            val main = Handler(Looper.getMainLooper())
            Thread {
                val msg = try {
                    val body = JSONObject()
                        .put("contents", JSONArray().put(
                            JSONObject().put("role", "user")
                                .put("parts", JSONArray().put(JSONObject().put("text", "Balas hanya dengan kata: OK")))
                        ))
                        .put("generationConfig", JSONObject().put("maxOutputTokens", 20))
                        .toString()
                    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 6000
                        readTimeout = 10000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("x-goog-api-key", apiKey)
                    }
                    conn.outputStream.use { it.write(body.toByteArray()) }
                    val code = conn.responseCode
                    conn.disconnect()
                    when (code) {
                        200 -> "Berhasil: API key dan model berfungsi"
                        400, 401, 403 -> "API key ditolak (kode $code). Cek lagi key-nya"
                        404 -> "Model tidak ditemukan (kode 404). Kosongkan kolom model atau ganti nama model"
                        429 -> "Key valid, tapi batas pemakaian gratis sedang tercapai (kode 429)"
                        else -> "Gagal, kode $code"
                    }
                } catch (e: Exception) {
                    "Gagal terhubung. Cek internet"
                }
                main.post { onResult(msg) }
            }.start()
        }
    }
}
