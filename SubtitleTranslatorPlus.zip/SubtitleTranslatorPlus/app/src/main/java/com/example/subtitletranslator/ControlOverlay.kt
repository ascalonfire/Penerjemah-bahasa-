package com.example.subtitletranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Panel kontrol kecil yang melayang: titik status AI (geser / ketuk untuk melipat),
 * atur area, jeda, geser subtitel, dan berhenti.
 */
class ControlOverlay(
    private val context: Context,
    private val showAreaButton: Boolean,
    private val onArea: () -> Unit,
    private val onPause: () -> Boolean,   // mengembalikan true jika sekarang dijeda
    private val onMove: () -> Unit,
    private val onStop: () -> Unit
) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var dot: TextView? = null
    private var pauseBtn: TextView? = null
    private val buttons = ArrayList<View>()

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    private fun prefs() =
        context.getSharedPreferences(ScreenTranslateService.PREFS, Context.MODE_PRIVATE)

    private fun label(text: String, onClick: () -> Unit) = TextView(context).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 16f
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { onClick() }
    }

    fun attach() {
        if (root != null) return
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs().getInt("ctl_x", dp(8))
            y = prefs().getInt("ctl_y", dp(120))
        }

        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(170, 20, 20, 20))
        }

        val d = TextView(context).apply {
            text = "●"
            textSize = 18f
            setTextColor(Color.GRAY)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        dot = d
        bar.addView(d)

        if (showAreaButton) {
            val b = label("▢") { onArea() }
            buttons.add(b); bar.addView(b)
        }
        val pb = label("⏸") {
            val paused = onPause()
            pauseBtn?.text = if (paused) "▶" else "⏸"
        }
        pauseBtn = pb
        buttons.add(pb); bar.addView(pb)
        val mv = label("↕") { onMove() }
        buttons.add(mv); bar.addView(mv)
        val st = label("■") { onStop() }
        buttons.add(st); bar.addView(st)

        // geser panel lewat titik; ketukan singkat = lipat/buka
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        d.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > dp(6) || abs(e.rawY - sy) > dp(6)) moved = true
                    if (moved) {
                        p.x = (ox + (e.rawX - sx)).toInt().coerceAtLeast(0)
                        p.y = (oy + (e.rawY - sy)).toInt().coerceAtLeast(0)
                        wm.updateViewLayout(bar, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs().edit().putInt("ctl_x", p.x).putInt("ctl_y", p.y).apply()
                    } else {
                        val vis = if (buttons.firstOrNull()?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                        buttons.forEach { it.visibility = vis }
                    }
                }
            }
            true
        }

        root = bar
        params = p
        wm.addView(bar, p)
    }

    fun setStatus(color: Int) {
        dot?.setTextColor(color)
    }

    fun detach() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        params = null
    }
}
