package com.example.subtitletranslator

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Riwayat terjemahan sesi terakhir, disimpan di file agar bisa diekspor ke .srt dari layar utama. */
object HistoryStore {

    private class Entry(val startMs: Long, var endMs: Long, var text: String)

    private val entries = ArrayList<Entry>()
    private var current: Entry? = null
    private var sessionStart = 0L
    private var appContext: Context? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "history.json")

    /** Mulai sesi baru: riwayat lama dibuang. */
    fun startSession(ctx: Context) {
        appContext = ctx.applicationContext
        entries.clear()
        current = null
        sessionStart = SystemClock.elapsedRealtime()
        save()
    }

    fun begin(text: String) {
        finish()
        val now = SystemClock.elapsedRealtime() - sessionStart
        val e = Entry(now, now, text)
        entries.add(e)
        current = e
        save()
    }

    /** Ganti teks entri yang sedang tampil (hasil AI untuk kalimat yang sama). */
    fun update(text: String) {
        current?.text = text
    }

    fun finish() {
        val e = current ?: return
        e.endMs = SystemClock.elapsedRealtime() - sessionStart
        current = null
        save()
    }

    private fun save() {
        val ctx = appContext ?: return
        runCatching {
            val arr = JSONArray()
            for (e in entries) {
                arr.put(JSONObject().put("s", e.startMs).put("e", e.endMs).put("t", e.text))
            }
            file(ctx).writeText(arr.toString())
        }
    }

    fun clear(ctx: Context) {
        entries.clear()
        current = null
        runCatching { file(ctx).delete() }
    }

    private fun fmt(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms / 60_000) % 60
        val s = (ms / 1000) % 60
        val milli = ms % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, milli)
    }

    /** Baca dari file (aman dipanggil dari aktivitas) dan ubah ke format SRT. null = kosong. */
    fun toSrt(ctx: Context): String? {
        val f = file(ctx)
        if (!f.exists()) return null
        val arr = runCatching { JSONArray(f.readText()) }.getOrNull() ?: return null
        if (arr.length() == 0) return null
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val start = o.getLong("s")
            var end = o.getLong("e")
            if (i + 1 < arr.length()) end = minOf(end, arr.getJSONObject(i + 1).getLong("s"))
            if (end <= start) end = start + 1500
            sb.append(i + 1).append('\n')
                .append(fmt(start)).append(" --> ").append(fmt(end)).append('\n')
                .append(o.getString("t")).append("\n\n")
        }
        return sb.toString()
    }
}
