package com.example.subtitletranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayManager(private val context: Context) {

    private val wm = context.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var textView: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var screenW = 0
    private var screenH = 0

    // penundaan/waktu baca
    private var holdUntil = 0L
    private var pendingText: String? = null
    private var pendingSource: String? = null
    private var pendingSticky = false
    private var pendingHide = false
    private val applyPending = Runnable {
        val t = pendingText
        pendingText = null
        if (t != null) apply(t, pendingSticky, pendingSource)
        else if (pendingHide) showHandle()
        pendingHide = false
    }
    private val fadeRunnable = Runnable {
        textView?.visibility = View.INVISIBLE
        setTouchable(false)
    }

    fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    private fun prefs() =
        context.getSharedPreferences(ScreenTranslateService.PREFS, Context.MODE_PRIVATE)

    // ---------- Pengaturan tampilan ----------

    private fun textSizeSp() = prefs().getInt("ov_size", 18).toFloat()

    private fun textColor() = when (prefs().getString("ov_color", "white")) {
        "yellow" -> Color.YELLOW
        "green" -> Color.rgb(144, 238, 144)
        else -> Color.WHITE
    }

    private fun bgColor() = Color.argb((prefs().getInt("ov_bg", 75) * 255 / 100).coerceIn(0, 255), 0, 0, 0)

    private fun bilingual() = prefs().getBoolean("bilingual", false)

    /** 0 = tidak ditahan (seperti versi 1.5), 1..3 = makin lama. */
    private fun holdScale() = when (prefs().getInt("hold_level", 0)) {
        1 -> 1f
        2 -> 1.6f
        3 -> 2.4f
        else -> 0f
    }

    private fun fadeEnabled() =
        prefs().getBoolean("handle_fade", true) && prefs().getBoolean("float_ctrl", true)

    private fun holdFor(text: String): Long {
        val scale = holdScale()
        if (scale == 0f) return 0L
        return ((1500L + 55L * text.length) * scale).toLong().coerceIn(1500L, 9000L)
    }

    // ---------- Posisi ----------

    private fun suffix() = if (screenW > screenH) "_l" else ""

    private fun savePosition(p: WindowManager.LayoutParams) {
        prefs().edit()
            .putInt("ov_x${suffix()}", p.x)
            .putInt("ov_y${suffix()}", p.y)
            .apply()
    }

    private fun applyPosition(p: WindowManager.LayoutParams, defaultY: Int) {
        val pr = prefs()
        val key = suffix()
        if (pr.contains("ov_y$key")) {
            p.x = pr.getInt("ov_x$key", 0)
            p.y = pr.getInt("ov_y$key", defaultY)
        } else {
            p.x = 0
            p.y = defaultY
        }
        clamp(p)
    }

    private fun clamp(p: WindowManager.LayoutParams) {
        if (screenW <= 0 || screenH <= 0) return
        p.x = p.x.coerceIn(-screenW / 2, screenW / 2)
        p.y = p.y.coerceIn(0, screenH - dp(48))
    }

    private fun setTouchable(touchable: Boolean) {
        val tv = textView ?: return
        val p = params ?: return
        val flag = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val newFlags = if (touchable) p.flags and flag.inv() else p.flags or flag
        if (newFlags != p.flags) {
            p.flags = newFlags
            runCatching { wm.updateViewLayout(tv, p) }
        }
    }

    // ---------- Siklus hidup ----------

    fun attach(screenWidth: Int, screenHeight: Int, bottomOffsetPx: Int) {
        if (textView != null) return
        screenW = screenWidth
        screenH = screenHeight

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }
        applyPosition(p, bottomOffsetPx)

        val tv = TextView(context).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            maxWidth = (screenWidth * 0.92f).toInt()
        }
        textView = tv
        params = p
        showHandle()

        var startX = 0f; var startY = 0f; var origX = 0; var origY = 0
        tv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY; origX = p.x; origY = p.y
                    handler.removeCallbacks(fadeRunnable)
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = origX + (e.rawX - startX).toInt()
                    p.y = origY - (e.rawY - startY).toInt() // gravity bawah: arah terbalik
                    clamp(p)
                    wm.updateViewLayout(tv, p)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    savePosition(p)
                    if (holdUntil == 0L && pendingText == null) scheduleFade()
                }
            }
            true
        }

        wm.addView(tv, p)
    }

    fun reset(screenWidth: Int, screenHeight: Int, bottomOffsetPx: Int) {
        val tv = textView ?: return
        val p = params ?: return
        screenW = screenWidth
        screenH = screenHeight
        applyPosition(p, bottomOffsetPx)
        tv.maxWidth = (screenWidth * 0.92f).toInt()
        wm.updateViewLayout(tv, p)
    }

    fun marginPx() = dp(8)

    // ---------- Menampilkan teks ----------

    private fun render(text: String, source: String?): CharSequence {
        if (!bilingual() || source.isNullOrBlank() || source == text) return text
        val sb = SpannableStringBuilder()
        sb.append(source)
        sb.setSpan(RelativeSizeSpan(0.65f), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(Color.LTGRAY), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append('\n').append(text)
        return sb
    }

    private fun styleForText(tv: TextView) {
        tv.setTextColor(textColor())
        tv.setBackgroundColor(bgColor())
        tv.textSize = textSizeSp()
        tv.alpha = 1f
        tv.visibility = View.VISIBLE
    }

    private fun apply(text: String, sticky: Boolean, source: String?) {
        handler.removeCallbacks(applyPending)
        handler.removeCallbacks(fadeRunnable)
        pendingText = null
        pendingHide = false
        textView?.let {
            setTouchable(true)
            styleForText(it)
            it.text = render(text, source)
        }
        val hold = holdFor(text)
        holdUntil = if (sticky && hold > 0) SystemClock.elapsedRealtime() + hold else 0L
    }

    /**
     * sticky: teks dilindungi selama waktu baca (jika diaktifkan di pengaturan).
     * force: pembaruan kalimat yang sama (mis. hasil AI), langsung ganti.
     * source: teks asli, ditampilkan kecil di atas jika mode dua baris aktif.
     */
    fun show(text: String, sticky: Boolean = false, force: Boolean = false, source: String? = null) {
        val now = SystemClock.elapsedRealtime()
        if (force) {
            textView?.let { it.text = render(text, source); styleForText(it) }
            return
        }
        if (now < holdUntil) {
            pendingText = text
            pendingSource = source
            pendingSticky = sticky
            pendingHide = false
            handler.removeCallbacks(applyPending)
            handler.postDelayed(applyPending, holdUntil - now)
            return
        }
        apply(text, sticky, source)
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeRunnable)
        if (fadeEnabled()) handler.postDelayed(fadeRunnable, 4000)
    }

    /** Tidak ada teks: pegangan kecil transparan; menghilang sendiri jika diaktifkan. */
    private fun showHandle() {
        val tv = textView ?: return
        setTouchable(true)
        tv.text = "⠿ geser"
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundColor(Color.argb(190, 0, 0, 0))
        tv.textSize = 12f
        tv.alpha = 0.35f
        tv.visibility = View.VISIBLE
        holdUntil = 0L
        scheduleFade()
    }

    /** Munculkan pegangan sebentar agar subtitel bisa digeser. */
    fun wakeHandle() {
        handler.removeCallbacks(applyPending)
        pendingText = null
        pendingHide = false
        showHandle()
        handler.removeCallbacks(fadeRunnable)
        if (fadeEnabled()) handler.postDelayed(fadeRunnable, 8000)
    }

    fun hide() {
        val now = SystemClock.elapsedRealtime()
        if (now < holdUntil) {
            pendingText = null
            pendingHide = true
            handler.removeCallbacks(applyPending)
            handler.postDelayed(applyPending, holdUntil - now)
        } else {
            showHandle()
        }
    }

    fun hideNow() {
        handler.removeCallbacks(applyPending)
        pendingText = null
        pendingHide = false
        holdUntil = 0L
        showHandle()
    }

    fun detach() {
        handler.removeCallbacks(applyPending)
        handler.removeCallbacks(fadeRunnable)
        textView?.let { runCatching { wm.removeView(it) } }
        textView = null
        params = null
    }
}
