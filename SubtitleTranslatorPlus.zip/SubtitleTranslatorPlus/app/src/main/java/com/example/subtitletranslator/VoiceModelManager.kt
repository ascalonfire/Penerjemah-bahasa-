package com.example.subtitletranslator

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Mengunduh model suara Vosk (sekali saja) ke penyimpanan aplikasi. */
object VoiceModelManager {

    private class Spec(val url: String, val dir: String)

    private const val BASE = "https://alphacephei.com/vosk/models/"

    private val specs = mapOf(
        "latin" to Spec(BASE + "vosk-model-small-en-us-0.15.zip", "vosk-model-small-en-us-0.15"),
        "zh" to Spec(BASE + "vosk-model-small-cn-0.22.zip", "vosk-model-small-cn-0.22"),
        "ja" to Spec(BASE + "vosk-model-small-ja-0.22.zip", "vosk-model-small-ja-0.22"),
        "ko" to Spec(BASE + "vosk-model-small-ko-0.22.zip", "vosk-model-small-ko-0.22")
    )

    private fun spec(lang: String) = specs[lang] ?: specs.getValue("latin")

    private fun targetDir(ctx: Context, lang: String) =
        File(File(ctx.filesDir, "vosk"), spec(lang).dir)

    fun isReady(ctx: Context, lang: String) =
        File(targetDir(ctx, lang), ".complete").exists()

    /** Blocking. Panggil dari background thread. onProgress: 0..100. */
    fun ensureModel(ctx: Context, lang: String, onProgress: (Int) -> Unit): File {
        val target = targetDir(ctx, lang)
        if (File(target, ".complete").exists()) return target

        val sp = spec(lang)
        val root = File(ctx.filesDir, "vosk").apply { mkdirs() }
        target.deleteRecursively()

        val tmp = File(ctx.cacheDir, "voice-model.zip")
        val conn = URL(sp.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        try {
            val total = conn.contentLengthLong
            var done = 0L
            var lastPct = -1
            conn.inputStream.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 90 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                        }
                    }
                }
            }
        } finally {
            conn.disconnect()
        }

        onProgress(92)
        val rootCanon = root.canonicalPath + File.separator
        ZipInputStream(FileInputStream(tmp)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val f = File(root, entry.name)
                require(f.canonicalPath.startsWith(rootCanon)) { "Zip tidak valid" }
                if (entry.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zis.copyTo(it) }
                }
                entry = zis.nextEntry
            }
        }
        tmp.delete()
        check(target.isDirectory) { "Folder model tidak ditemukan setelah ekstrak" }
        File(target, ".complete").writeText("ok")
        onProgress(100)
        return target
    }
}
