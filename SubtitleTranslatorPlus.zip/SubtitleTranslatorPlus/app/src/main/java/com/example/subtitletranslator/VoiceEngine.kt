package com.example.subtitletranslator

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import androidx.annotation.RequiresApi
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Menangkap audio yang diputar di HP (AudioPlaybackCapture, Android 10+),
 * mengubahnya jadi teks secara streaming dengan Vosk (offline).
 * Callback dipanggil di thread internal: pindahkan ke main thread sendiri.
 */
@RequiresApi(29)
class VoiceEngine(
    private val modelPath: String,
    private val projection: MediaProjection,
    private val onText: (text: String, isFinal: Boolean) -> Unit,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var running = false
    private var thread: Thread? = null

    private companion object {
        const val CAPTURE_RATE = 48000 // didecimasi 3:1 -> 16000 Hz untuk Vosk
    }

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "voice-engine").also { it.start() }
    }

    fun stop() {
        running = false
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        var model: Model? = null
        var recognizer: Recognizer? = null
        var record: AudioRecord? = null
        try {
            onStatus("Memuat model suara…")
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            model = Model(modelPath)
            recognizer = Recognizer(model, 16000.0f)

            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(CAPTURE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                CAPTURE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            record = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 4800 * 2 * 4))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                onStatus("Gagal menangkap audio (aplikasi mungkin memblokir perekaman)")
                return
            }
            record.startRecording()
            onStatus("Mendengarkan audio…")

            val inBuf = ShortArray(4800)   // 100 ms @ 48 kHz
            val outBuf = ShortArray(1600)  // 100 ms @ 16 kHz
            while (running) {
                val n = record.read(inBuf, 0, inBuf.size)
                if (n < 0) break
                if (n < 3) continue
                val m = n / 3
                for (i in 0 until m) {
                    val sum = inBuf[3 * i] + inBuf[3 * i + 1] + inBuf[3 * i + 2]
                    outBuf[i] = (sum / 3).toShort()
                }
                if (recognizer.acceptWaveForm(outBuf, m)) {
                    val t = JSONObject(recognizer.result).optString("text")
                    if (t.isNotBlank()) onText(t, true)
                } else {
                    val t = JSONObject(recognizer.partialResult).optString("partial")
                    if (t.isNotBlank()) onText(t, false)
                }
            }
        } catch (e: Throwable) {
            onStatus("Suara gagal: ${e.message}")
        } finally {
            runCatching { record?.stop() }
            runCatching { record?.release() }
            runCatching { recognizer?.close() }
            runCatching { model?.close() }
        }
    }
}
