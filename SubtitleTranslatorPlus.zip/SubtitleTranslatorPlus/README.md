# Subtitle Translator Plus

Aplikasi terpisah dari Subtitle Translator (application id berbeda, bisa dipasang berdampingan).

Fitur tambahan: pengaturan tampilan subtitel (ukuran, warna, latar), tes API key, glosarium untuk AI, panel tombol melayang (jeda, atur area, geser, berhenti), tampilan dua baris (teks asli + terjemahan), pengaturan lama subtitel tampil, pegangan geser yang hilang otomatis, riwayat dan ekspor .srt, serta indikator status AI.

Dibuat oleh ascalonfire. © 2026 ascalonfire.

Pustaka pihak ketiga: Google ML Kit (OCR, terjemahan, deteksi bahasa) dan Vosk (pengenalan suara, Apache License 2.0). Model suara Vosk memiliki lisensinya sendiri.

## Mode AI (opsional)

Terjemahan ML Kit tampil lebih dulu, lalu diperhalus oleh Google Gemini. Jika internet putus, batas tercapai, atau key salah, aplikasi tetap memakai terjemahan ML Kit. Teks subtitel dikirim ke server Google saat mode ini aktif; jelaskan hal ini di kebijakan privasi jika aplikasi dipublikasikan.
