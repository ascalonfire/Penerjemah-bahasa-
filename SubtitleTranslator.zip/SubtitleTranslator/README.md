# Subtitle Translator (OCR layar -> terjemahan -> overlay)

- Kotak seleksi area yang bisa digeser/diubah ukurannya
- OCR: Latin, Mandarin, Jepang, Korea -> terjemahan ke Indonesia
- Build: unggah zip ke GitHub, workflow membangun APK debug.
