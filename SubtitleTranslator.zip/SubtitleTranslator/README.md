# Subtitle Translator

- Mode teks: OCR layar (Latin/Mandarin/Jepang/Korea) dengan kotak area yang bisa digeser
- Mode suara: tangkap audio yang diputar (Android 10+) -> Vosk (offline) -> terjemahan Indonesia
- Ikon aplikasi adaptif (res/mipmap-anydpi-v26)
- Build: unggah zip ke GitHub, workflow membangun APK debug.
