# Subtitle Translator (OCR layar -> terjemahan -> overlay)

1. Buka folder ini di Android Studio (Koala/2024.1+), tunggu Gradle sync.
2. Jalankan di perangkat nyata (Android 8.0+).
3. Beri izin overlay, atur area subtitel, tekan "Mulai terjemahan".

Target bahasa: Indonesia (ubah di TranslatorManager). OCR: teks Latin.
