package com.example.subtitletranslator

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

private fun clampTo(v: Int, lo: Int, hi: Int) = if (hi < lo) lo else v.coerceIn(lo, hi)

/**
 * Kotak seleksi melayang: geser untuk memindah, tarik sudut kanan-bawah untuk mengubah ukuran,
 * ketuk tombol ✓ (kanan-atas) untuk mengunci area.
 * Window hanya seukuran kotak, jadi sentuhan di luar kotak tetap mengenai aplikasi di bawahnya.
 */
class SelectionOverlay(
    private val context: Context,
    private val onLock: (Rect) -> Unit
) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private var view: SelectionView? = null
    private var params: WindowManager.LayoutParams? = null
    private var screenW = 0
    private var screenH = 0

    @Volatile
    var showing = false
        private set

    fun show(rect: Rect, w: Int, h: Int) {
        screenW = w
        screenH = h
        if (showing) { update(rect, w, h); return }

        val p = WindowManager.LayoutParams(
            rect.width(), rect.height(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = rect.left
            y = rect.top
        }
        val v = SelectionView(context, p, wm, { screenW }, { screenH }) { onLock(currentRect()) }
        wm.addView(v, p)
        view = v
        params = p
        showing = true
    }

    fun update(rect: Rect, w: Int, h: Int) {
        screenW = w
        screenH = h
        val p = params ?: return
        val v = view ?: return
        p.x = rect.left
        p.y = rect.top
        p.width = rect.width()
        p.height = rect.height()
        wm.updateViewLayout(v, p)
    }

    fun currentRect(): Rect {
        val p = params ?: return Rect()
        return Rect(p.x, p.y, p.x + p.width, p.y + p.height)
    }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        params = null
        showing = false
    }
}

@SuppressLint("ViewConstructor")
class SelectionView(
    ctx: Context,
    private val p: WindowManager.LayoutParams,
    private val wm: WindowManager,
    private val screenW: () -> Int,
    private val screenH: () -> Int,
    private val onLockTap: () -> Unit
) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val handle = 36 * d
    private val btn = 40 * d
    private val minW = (140 * d).toInt()
    private val minH = (80 * d).toInt()

    private val fillPaint = Paint().apply { color = Color.argb(40, 0, 188, 212) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 188, 212); style = Paint.Style.STROKE; strokeWidth = 2 * d
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 188, 212) }
    private val okPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(46, 160, 67) }
    private val checkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 22 * d; textAlign = Paint.Align.CENTER
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12 * d
        setShadowLayer(3 * d, 0f, 0f, Color.BLACK)
    }

    private val MOVE = 0
    private val RESIZE = 1
    private val LOCK = 2
    private var mode = MOVE
    private var startX = 0f
    private var startY = 0f
    private var origX = 0
    private var origY = 0
    private var origW = 0
    private var origH = 0

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, fillPaint)
        canvas.drawRect(d, d, w - d, h - d, borderPaint)
        canvas.drawText("Area terjemahan", 8 * d, 18 * d, labelPaint)

        canvas.drawCircle(w - handle / 2, h - handle / 2, handle / 3, handlePaint)

        val cx = w - btn / 2
        val cy = btn / 2
        canvas.drawCircle(cx, cy, btn / 2.5f, okPaint)
        canvas.drawText("✓", cx, cy + 8 * d, checkPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = when {
                    e.x > width - handle && e.y > height - handle -> RESIZE
                    e.x > width - btn && e.y < btn -> LOCK
                    else -> MOVE
                }
                startX = e.rawX; startY = e.rawY
                origX = p.x; origY = p.y; origW = p.width; origH = p.height
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == LOCK) return true
                val dx = (e.rawX - startX).toInt()
                val dy = (e.rawY - startY).toInt()
                if (mode == MOVE) {
                    p.x = clampTo(origX + dx, 0, screenW() - p.width)
                    p.y = clampTo(origY + dy, 0, screenH() - p.height)
                } else {
                    p.width = clampTo(origW + dx, minW, screenW() - p.x)
                    p.height = clampTo(origH + dy, minH, screenH() - p.y)
                }
                wm.updateViewLayout(this, p)
            }
            MotionEvent.ACTION_UP -> {
                if (mode == LOCK && e.x > width - btn && e.y < btn) onLockTap()
            }
        }
        return true
    }
}
