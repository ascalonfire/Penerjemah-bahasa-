package com.example.subtitletranslator

import android.graphics.Bitmap
import android.graphics.Color
import android.media.Image

object ImageUtils {

    /**
     * Salin hanya baris-baris area crop dari frame RGBA_8888 (hemat memori/CPU).
     * Crop vertikal saja (lebar penuh).
     */
    fun cropRows(image: Image, top: Int, bottom: Int): Bitmap? {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPixels = rowStride / pixelStride

        val t = top.coerceIn(0, image.height - 2)
        var rows = (bottom - t).coerceAtLeast(1)
        val available = (buffer.limit() - t * rowStride) / rowStride
        rows = rows.coerceAtMost(available)
        if (rows < 1) return null

        val buf = buffer.duplicate()
        buf.position(t * rowStride)
        val wide = Bitmap.createBitmap(rowPixels, rows, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(buf)
        if (rowPixels == image.width) return wide
        val cropped = Bitmap.createBitmap(wide, 0, 0, image.width, rows)
        wide.recycle()
        return cropped
    }

    /** Tanda tangan kecil (32x8 luminans) untuk mendeteksi frame yang sama. */
    fun signature(bitmap: Bitmap): IntArray {
        val small = Bitmap.createScaledBitmap(bitmap, 32, 8, true)
        val px = IntArray(32 * 8)
        small.getPixels(px, 0, 32, 0, 0, 32, 8)
        if (small !== bitmap) small.recycle()
        return IntArray(px.size) {
            val c = px[it]
            (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
        }
    }

    fun meanDiff(a: IntArray, b: IntArray): Float {
        var sum = 0L
        for (i in a.indices) sum += kotlin.math.abs(a[i] - b[i])
        return sum.toFloat() / a.size
    }

    /** Perbesar 2x jika area crop pendek agar OCR lebih akurat. */
    fun preprocess(src: Bitmap): Bitmap {
        if (src.height >= 200) return src
        val scaled = Bitmap.createScaledBitmap(src, src.width * 2, src.height * 2, true)
        if (scaled !== src) src.recycle()
        return scaled
    }
}
