package com.example.subtitletranslator

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * forcedSource: kode bahasa sumber tetap (mis. "zh"). Jika null, bahasa dideteksi otomatis.
 */
class TranslatorManager(
    private val forcedSource: String? = null,
    private val target: String = TranslateLanguage.INDONESIAN
) {

    private val langId = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.5f).build()
    )
    private val translators = HashMap<String, Translator>()
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>) = size > 200
    }

    /** Semua dipanggil di main thread. onResult(null) = tidak diterjemahkan/gagal. */
    fun translate(text: String, onResult: (String?) -> Unit) {
        cache[text]?.let { onResult(it); return }

        if (forcedSource != null) {
            translateWith(forcedSource, text, onResult)
            return
        }

        langId.identifyLanguage(text)
            .addOnSuccessListener { code ->
                val src = if (code == "und") null else TranslateLanguage.fromLanguageTag(code)
                if (src == null || src == target) onResult(null)
                else translateWith(src, text, onResult)
            }
            .addOnFailureListener { onResult(null) }
    }

    private fun getTranslator(src: String): Translator = translators.getOrPut(src) {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(target)
                .build()
        )
    }

    /** Unduh + muat model di awal supaya terjemahan pertama tidak lambat. */
    fun warmUp() {
        val t = getTranslator(forcedSource ?: TranslateLanguage.ENGLISH)
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { t.translate("hello") }
    }

    private fun translateWith(src: String, text: String, onResult: (String?) -> Unit) {
        val translator = getTranslator(src)
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { result ->
                        cache[text] = result
                        onResult(result)
                    }
                    .addOnFailureListener { onResult(null) }
            }
            .addOnFailureListener { onResult(null) }
    }

    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
        langId.close()
    }
}
