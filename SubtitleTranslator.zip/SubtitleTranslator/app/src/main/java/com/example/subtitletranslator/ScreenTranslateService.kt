package com.example.subtitletranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import java.util.concurrent.atomic.AtomicBoolean

class ScreenTranslateService : Service() {

    companion object {
        const val ACTION_START = "com.example.subtitletranslator.START"
        const val ACTION_STOP = "com.example.subtitletranslator.STOP"
        const val ACTION_TOGGLE_BOX = "com.example.subtitletranslator.TOGGLE_BOX"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val PREFS = "settings"
        const val KEY_LANG = "ocr_lang"

        private const val CHANNEL_ID = "screen_translate"
        private const val NOTIF_ID = 1
        private const val MIN_INTERVAL_MS = 350L   // ~3 FPS
        private const val STATIC_DIFF = 2f         // di bawah ini = frame dianggap sama
        private const val MAX_TEXT = 300
    }

    private data class ScreenInfo(val w: Int, val h: Int, val dpi: Int)

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var workThread: HandlerThread
    private lateinit var workHandler: Handler

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var overlay: OverlayManager
    private lateinit var selection: SelectionOverlay
    private lateinit var ocr: OcrProcessor
    private lateinit var translator: TranslatorManager

    private val busy = AtomicBoolean(false)
    private var lastFrameTime = 0L
    private var lastOcrSig: IntArray? = null
    @Volatile private var lastOcrText: String = ""

    // state debounce (hanya main thread)
    private var pending: String? = null
    private var stableCount = 0
    private var emptyCount = 0
    private var shownSource: String? = null
    private var translating: String? = null

    override fun onCreate() {
        super.onCreate()
        workThread = HandlerThread("ocr-work").also { it.start() }
        workHandler = Handler(workThread.looper)

        val lang = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LANG, "latin") ?: "latin"
        overlay = OverlayManager(this)
        ocr = OcrProcessor(lang)
        translator = TranslatorManager(
            when (lang) {
                "zh" -> TranslateLanguage.CHINESE
                "ja" -> TranslateLanguage.JAPANESE
                "ko" -> TranslateLanguage.KOREAN
                else -> null
            }
        )
        selection = SelectionOverlay(this) { rect -> onBoxLocked(rect) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        when (intent.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE_BOX -> {
                if (projection == null) stopSelf() else toggleBox()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startInForeground() // wajib sebelum getMediaProjection (Android 14+)
                if (projection == null) {
                    val code = intent.getIntExtra(EXTRA_CODE, 0)
                    val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
                    if (data == null) { stopSelf(); return START_NOT_STICKY }
                    startCapture(code, data)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Penerjemah layar", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenTranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val boxPi = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenTranslateService::class.java).setAction(ACTION_TOGGLE_BOX),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val notif = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Subtitle Translator aktif")
            .setContentText("Ketuk 'Atur area' untuk memindah kotak terjemahan")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_crop, "Atur area", boxPi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", stopPi)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    // ---------- Area seleksi ----------

    private fun boxRect(w: Int, h: Int): Rect {
        val pr = getSharedPreferences(PREFS, MODE_PRIVATE)
        val land = w > h
        val s = if (land) "_l" else ""
        val l = pr.getFloat("box_l$s", if (land) 0.10f else 0.05f)
        val t = pr.getFloat("box_t$s", if (land) 0.78f else 0.75f)
        val r = pr.getFloat("box_r$s", if (land) 0.90f else 0.95f)
        val b = pr.getFloat("box_b$s", if (land) 0.95f else 0.92f)
        return Rect((l * w).toInt(), (t * h).toInt(), (r * w).toInt(), (b * h).toInt())
    }

    private fun saveBox(rect: Rect, w: Int, h: Int) {
        val s = if (w > h) "_l" else ""
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putFloat("box_l$s", rect.left.toFloat() / w)
            .putFloat("box_t$s", rect.top.toFloat() / h)
            .putFloat("box_r$s", rect.right.toFloat() / w)
            .putFloat("box_b$s", rect.bottom.toFloat() / h)
            .apply()
    }

    /** Terjemahan ditaruh di luar kotak (atas, atau bawah jika kotak dekat tepi atas). */
    private fun overlayBottomOffset(box: Rect, screenH: Int): Int {
        val margin = overlay.dp(8)
        return if (box.top > screenH * 0.2f) {
            screenH - box.top + margin
        } else {
            (screenH - box.bottom - margin - overlay.dp(90)).coerceAtLeast(0)
        }
    }

    private fun resetState() {
        lastOcrSig = null
        lastOcrText = ""
        pending = null
        stableCount = 0
        emptyCount = 0
        shownSource = null
        translating = null
    }

    private fun onBoxLocked(rect: Rect) {
        val s = screenInfo()
        saveBox(rect, s.w, s.h)
        selection.hide()
        overlay.reset(s.w, overlayBottomOffset(rect, s.h))
        resetState()
        Toast.makeText(this, "Area dikunci. Terjemahan aktif.", Toast.LENGTH_SHORT).show()
    }

    private fun toggleBox() {
        if (selection.showing) {
            onBoxLocked(selection.currentRect())
        } else {
            showBox()
        }
    }

    private fun showBox() {
        val s = screenInfo()
        overlay.hide()
        resetState()
        selection.show(boxRect(s.w, s.h), s.w, s.h)
        Toast.makeText(
            this,
            "Geser kotak ke subtitel, tarik sudut kanan-bawah untuk ukuran, ketuk ✓ untuk kunci",
            Toast.LENGTH_LONG
        ).show()
    }

    // ---------- Capture ----------

    private fun screenInfo(): ScreenInfo {
        val dm = getSystemService(DisplayManager::class.java)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metrics)
        return ScreenInfo(metrics.widthPixels, metrics.heightPixels, metrics.densityDpi)
    }

    private fun newReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2).also {
            it.setOnImageAvailableListener({ r -> onFrame(r) }, workHandler)
        }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        // Android 14+: callback harus didaftarkan sebelum createVirtualDisplay
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { mainHandler.post { stopSelf() } }
        }, mainHandler)
        projection = p

        val s = screenInfo()
        val reader = newReader(s.w, s.h)
        imageReader = reader
        virtualDisplay = p.createVirtualDisplay(
            "SubtitleTranslate", s.w, s.h, s.dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )

        overlay.attach(s.w, overlayBottomOffset(boxRect(s.w, s.h), s.h))
        showBox() // mulai dengan mode atur area
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val vd = virtualDisplay ?: return
        val s = screenInfo()
        val old = imageReader
        val reader = newReader(s.w, s.h)
        imageReader = reader
        vd.resize(s.w, s.h, s.dpi)
        vd.surface = reader.surface
        runCatching { old?.close() }

        val rect = boxRect(s.w, s.h)
        if (selection.showing) selection.update(rect, s.w, s.h)
        overlay.reset(s.w, overlayBottomOffset(rect, s.h))
        resetState()
    }

    // ---------- Frame pipeline (work thread) ----------

    private fun onFrame(reader: ImageReader) {
        val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            if (selection.showing) return // sedang mengatur area: jeda OCR
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameTime < MIN_INTERVAL_MS || busy.get()) return
            lastFrameTime = now

            val crop = ImageUtils.crop(image, boxRect(image.width, image.height)) ?: return

            val sig = ImageUtils.signature(crop)
            val prev = lastOcrSig
            if (prev != null && ImageUtils.meanDiff(sig, prev) < STATIC_DIFF) {
                // frame sama dengan OCR terakhir: hemat CPU, hitung sebagai konfirmasi teks
                crop.recycle()
                val text = lastOcrText
                mainHandler.post { onTextObserved(text) }
                return
            }
            lastOcrSig = sig

            if (!busy.compareAndSet(false, true)) { crop.recycle(); return }
            val prepared = ImageUtils.preprocess(crop)
            mainHandler.post {
                ocr.recognize(prepared) { raw ->
                    prepared.recycle()
                    if (raw != null) {
                        val clean = raw.replace(Regex("\\s+"), " ").trim().take(MAX_TEXT)
                        lastOcrText = clean
                        onTextObserved(clean)
                    }
                    busy.set(false)
                }
            }
        } catch (e: Exception) {
            busy.set(false)
        } finally {
            image.close()
        }
    }

    // ---------- Debounce + terjemahan (main thread) ----------

    private fun onTextObserved(text: String) {
        if (selection.showing) return
        if (text.length < 2) {
            if (++emptyCount >= 2) {
                overlay.hide()
                pending = null
                shownSource = null
                stableCount = 0
            }
            return
        }
        emptyCount = 0
        if (text == pending) stableCount++ else { pending = text; stableCount = 1 }

        // terjemahkan hanya jika teks stabil 2 pengamatan berturut-turut
        if (stableCount >= 2 && text != shownSource && text != translating) {
            translating = text
            translator.translate(text) { result ->
                translating = null
                if (result != null && pending == text && !selection.showing) {
                    shownSource = text
                    overlay.show(result)
                }
            }
        }
    }

    // ---------- Cleanup ----------

    override fun onDestroy() {
        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.close() }
        runCatching { projection?.stop() }
        virtualDisplay = null
        imageReader = null
        projection = null
        selection.hide()
        overlay.detach()
        translator.close()
        ocr.close()
        workThread.quitSafely()
        super.onDestroy()
    }
}
