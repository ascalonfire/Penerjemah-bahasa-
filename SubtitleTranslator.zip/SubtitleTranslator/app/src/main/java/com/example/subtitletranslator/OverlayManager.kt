package com.example.subtitletranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayManager(private val context: Context) {

    private val wm = context.getSystemService(WindowManager::class.java)
    private var textView: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var holdUntil = 0L
    private var pendingText: String? = null
    private var pendingSticky = false
    private var pendingHide = false
    private val applyPending = Runnable {
        val t = pendingText
        pendingText = null
        if (t != null) apply(t, pendingSticky) else if (pendingHide) showHandle()
        pendingHide = false
    }

    private var screenW = 0
    private var screenH = 0

    fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    private fun prefs() =
        context.getSharedPreferences(ScreenTranslateService.PREFS, Context.MODE_PRIVATE)

    private fun suffix() = if (screenW > screenH) "_l" else ""

    private fun savePosition(p: WindowManager.LayoutParams) {
        prefs().edit()
            .putInt("ov_x${suffix()}", p.x)
            .putInt("ov_y${suffix()}", p.y)
            .apply()
    }

    /** Pakai posisi yang pernah digeser pengguna, kalau ada; kalau tidak, pakai bawaan. */
    private fun applyPosition(p: WindowManager.LayoutParams, defaultY: Int) {
        val pr = prefs()
        val key = suffix()
        if (pr.contains("ov_y$key")) {
            p.x = pr.getInt("ov_x$key", 0)
            p.y = pr.getInt("ov_y$key", defaultY)
        } else {
            p.x = 0
            p.y = defaultY
        }
        clamp(p)
    }

    private fun clamp(p: WindowManager.LayoutParams) {
        if (screenW <= 0 || screenH <= 0) return
        p.x = p.x.coerceIn(-screenW / 2, screenW / 2)
        p.y = p.y.coerceIn(0, screenH - dp(48))
    }

    fun attach(screenWidth: Int, screenHeight: Int, bottomOffsetPx: Int) {
        if (textView != null) return
        screenW = screenWidth
        screenH = screenHeight

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }
        applyPosition(p, bottomOffsetPx)

        val tv = TextView(context).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(190, 0, 0, 0))
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            maxWidth = (screenWidth * 0.92f).toInt()
        }
        textView = tv
        params = p
        showHandle() // selalu terlihat agar bisa dipegang dan digeser

        var startX = 0f; var startY = 0f; var origX = 0; var origY = 0
        tv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY; origX = p.x; origY = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = origX + (e.rawX - startX).toInt()
                    p.y = origY - (e.rawY - startY).toInt() // gravity bawah: arah terbalik
                    clamp(p)
                    wm.updateViewLayout(tv, p)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> savePosition(p)
            }
            true
        }

        wm.addView(tv, p)
    }

    /** Posisikan ulang (mis. setelah rotasi atau area dikunci). */
    fun reset(screenWidth: Int, screenHeight: Int, bottomOffsetPx: Int) {
        val tv = textView ?: return
        val p = params ?: return
        screenW = screenWidth
        screenH = screenHeight
        applyPosition(p, bottomOffsetPx)
        tv.maxWidth = (screenWidth * 0.92f).toInt()
        wm.updateViewLayout(tv, p)
    }

    fun marginPx() = dp(8)

    /** Lama minimal sebuah subtitel bertahan, menyesuaikan panjang teks supaya sempat dibaca. */
    private fun holdFor(text: String): Long = (1500L + 55L * text.length).coerceIn(1800L, 6000L)

    private fun apply(text: String, sticky: Boolean) {
        handler.removeCallbacks(applyPending)
        pendingText = null
        pendingHide = false
        textView?.apply {
            this.text = text
            textSize = 18f
            alpha = 1f
            visibility = View.VISIBLE
        }
        holdUntil = if (sticky) SystemClock.elapsedRealtime() + holdFor(text) else 0L
    }

    /**
     * sticky: teks ini dilindungi selama waktu baca minimal; teks lain yang datang saat itu
     *   ditunda (yang terbaru menang).
     * force: pembaruan untuk kalimat yang sama (mis. hasil AI), langsung ganti tanpa menunggu.
     */
    fun show(text: String, sticky: Boolean = false, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (force) {
            textView?.apply { this.text = text; alpha = 1f; visibility = View.VISIBLE }
            return
        }
        if (now < holdUntil) {
            pendingText = text
            pendingSticky = sticky
            pendingHide = false
            handler.removeCallbacks(applyPending)
            handler.postDelayed(applyPending, holdUntil - now)
            return
        }
        apply(text, sticky)
    }

    /** Tidak ada teks: tampilkan pegangan kecil transparan, bukan menghilangkan view. */
    private fun showHandle() {
        textView?.apply {
            text = "⠿ geser"
            textSize = 12f
            alpha = 0.35f
            visibility = View.VISIBLE
        }
    }

    /** Sembunyikan teks, tapi tunggu dulu kalau subtitel sekarang belum sempat terbaca. */
    fun hide() {
        val now = SystemClock.elapsedRealtime()
        if (now < holdUntil) {
            pendingText = null
            pendingHide = true
            handler.removeCallbacks(applyPending)
            handler.postDelayed(applyPending, holdUntil - now)
        } else {
            showHandle()
        }
    }

    /** Sembunyikan sekarang juga (mis. saat mengatur area). */
    fun hideNow() {
        handler.removeCallbacks(applyPending)
        pendingText = null
        pendingHide = false
        holdUntil = 0L
        showHandle()
    }

    fun detach() {
        handler.removeCallbacks(applyPending)
        textView?.let { runCatching { wm.removeView(it) } }
        textView = null
        params = null
    }
}
