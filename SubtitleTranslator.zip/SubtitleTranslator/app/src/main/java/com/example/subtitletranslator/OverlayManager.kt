package com.example.subtitletranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayManager(private val context: Context) {

    private val wm = context.getSystemService(WindowManager::class.java)
    private var textView: TextView? = null
    private var params: WindowManager.LayoutParams? = null

    fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    fun attach(screenWidth: Int, bottomOffsetPx: Int) {
        if (textView != null) return

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            x = 0
            y = bottomOffsetPx
        }

        val tv = TextView(context).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(190, 0, 0, 0))
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            maxWidth = (screenWidth * 0.92f).toInt()
            visibility = View.GONE
        }

        var startX = 0f; var startY = 0f; var origX = 0; var origY = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY; origX = p.x; origY = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = origX + (e.rawX - startX).toInt()
                    p.y = origY - (e.rawY - startY).toInt() // gravity bawah: arah terbalik
                    wm.updateViewLayout(tv, p)
                }
            }
            true
        }

        wm.addView(tv, p)
        textView = tv
        params = p
    }

    /** Posisikan ulang (mis. setelah rotasi). */
    fun reset(screenWidth: Int, bottomOffsetPx: Int) {
        val tv = textView ?: return
        val p = params ?: return
        p.x = 0
        p.y = bottomOffsetPx
        tv.maxWidth = (screenWidth * 0.92f).toInt()
        wm.updateViewLayout(tv, p)
    }

    fun marginPx() = dp(8)

    fun show(text: String) {
        textView?.apply { this.text = text; visibility = View.VISIBLE }
    }

    fun hide() {
        textView?.visibility = View.GONE
    }

    fun detach() {
        textView?.let { runCatching { wm.removeView(it) } }
        textView = null
        params = null
    }
}
