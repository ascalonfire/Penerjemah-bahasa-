package com.example.subtitletranslator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.core.widget.doAfterTextChanged
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_START)
                    .putExtra(ScreenTranslateService.EXTRA_CODE, result.resultCode)
                    .putExtra(ScreenTranslateService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, intent)
            } else {
                Toast.makeText(this, "Izin tangkap layar ditolak", Toast.LENGTH_SHORT).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val audioLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCapture()
            else Toast.makeText(this, "Izin mikrofon dibutuhkan untuk mode suara", Toast.LENGTH_LONG).show()
        }

    private fun launchCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        captureLauncher.launch(mpm.createScreenCaptureIntent())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val prefs = getSharedPreferences(ScreenTranslateService.PREFS, MODE_PRIVATE)

        val modeGroup = findViewById<RadioGroup>(R.id.rgMode)
        modeGroup.check(
            if (prefs.getString(ScreenTranslateService.KEY_MODE, "ocr") == "voice") R.id.rbModeVoice
            else R.id.rbModeOcr
        )
        modeGroup.setOnCheckedChangeListener { _, id ->
            val mode = if (id == R.id.rbModeVoice) "voice" else "ocr"
            prefs.edit().putString(ScreenTranslateService.KEY_MODE, mode).apply()
            Toast.makeText(this, "Tekan Berhenti lalu Mulai lagi agar mode berlaku", Toast.LENGTH_SHORT).show()
        }

        val group = findViewById<RadioGroup>(R.id.rgLang)
        group.check(
            when (prefs.getString(ScreenTranslateService.KEY_LANG, "latin")) {
                "zh" -> R.id.rbZh
                "ja" -> R.id.rbJa
                "ko" -> R.id.rbKo
                else -> R.id.rbLatin
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val lang = when (id) {
                R.id.rbZh -> "zh"
                R.id.rbJa -> "ja"
                R.id.rbKo -> "ko"
                else -> "latin"
            }
            prefs.edit().putString(ScreenTranslateService.KEY_LANG, lang).apply()
            Toast.makeText(this, "Tekan Berhenti lalu Mulai lagi agar bahasa berlaku", Toast.LENGTH_SHORT).show()
        }

        val casualBox = findViewById<CheckBox>(R.id.cbCasual)
        casualBox.isChecked = prefs.getBoolean("casual", true)
        casualBox.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("casual", checked).apply()
            Toast.makeText(this, "Tekan Berhenti lalu Mulai lagi agar gaya bahasa berlaku", Toast.LENGTH_SHORT).show()
        }

        val aiBox = findViewById<CheckBox>(R.id.cbAi)
        aiBox.isChecked = prefs.getBoolean("ai_on", false)
        aiBox.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("ai_on", checked).apply()
            Toast.makeText(this, "Tekan Berhenti lalu Mulai lagi agar AI berlaku", Toast.LENGTH_SHORT).show()
        }
        val keyField = findViewById<EditText>(R.id.etApiKey)
        keyField.setText(prefs.getString("gemini_key", ""))
        keyField.doAfterTextChanged { prefs.edit().putString("gemini_key", it?.toString()?.trim()).apply() }
        val modelField = findViewById<EditText>(R.id.etModel)
        modelField.setText(prefs.getString("gemini_model", ""))
        modelField.doAfterTextChanged { prefs.edit().putString("gemini_model", it?.toString()?.trim()).apply() }

        findViewById<Button>(R.id.btnOverlay).setOnClickListener { requestOverlayPermission() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan overlay dulu", Toast.LENGTH_SHORT).show()
                requestOverlayPermission()
                return@setOnClickListener
            }
            val voice = prefs.getString(ScreenTranslateService.KEY_MODE, "ocr") == "voice"
            if (voice) {
                if (Build.VERSION.SDK_INT < 29) {
                    Toast.makeText(this, "Mode suara butuh Android 10 ke atas", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    return@setOnClickListener
                }
            }
            launchCapture()
        }

        findViewById<Button>(R.id.btnArea).setOnClickListener {
            startService(
                Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_TOGGLE_BOX)
            )
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_STOP)
            )
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
        }
    }
}
