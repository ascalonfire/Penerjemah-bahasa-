package com.example.subtitletranslator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var tvTop: TextView
    private lateinit var tvBottom: TextView
    private lateinit var seekTop: SeekBar
    private lateinit var seekBottom: SeekBar

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_START)
                    .putExtra(ScreenTranslateService.EXTRA_CODE, result.resultCode)
                    .putExtra(ScreenTranslateService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, "Berjalan. Buka video Anda.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Izin tangkap layar ditolak", Toast.LENGTH_SHORT).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        tvTop = findViewById(R.id.tvTop)
        tvBottom = findViewById(R.id.tvBottom)
        seekTop = findViewById(R.id.seekTop)
        seekBottom = findViewById(R.id.seekBottom)

        val prefs = getSharedPreferences(ScreenTranslateService.PREFS, MODE_PRIVATE)
        seekTop.progress = prefs.getInt(ScreenTranslateService.KEY_TOP, 70)
        seekBottom.progress = prefs.getInt(ScreenTranslateService.KEY_BOTTOM, 95)
        updateLabels()

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                // pastikan bawah > atas minimal 5%
                if (sb === seekTop && seekTop.progress > seekBottom.progress - 5) {
                    seekTop.progress = (seekBottom.progress - 5).coerceAtLeast(0)
                }
                if (sb === seekBottom && seekBottom.progress < seekTop.progress + 5) {
                    seekBottom.progress = (seekTop.progress + 5).coerceAtMost(100)
                }
                prefs.edit()
                    .putInt(ScreenTranslateService.KEY_TOP, seekTop.progress)
                    .putInt(ScreenTranslateService.KEY_BOTTOM, seekBottom.progress)
                    .apply()
                updateLabels()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        }
        seekTop.setOnSeekBarChangeListener(listener)
        seekBottom.setOnSeekBarChangeListener(listener)

        findViewById<Button>(R.id.btnOverlay).setOnClickListener { requestOverlayPermission() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan overlay dulu", Toast.LENGTH_SHORT).show()
                requestOverlayPermission()
                return@setOnClickListener
            }
            val mpm = getSystemService(MediaProjectionManager::class.java)
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_STOP)
            )
        }
    }

    private fun updateLabels() {
        tvTop.text = "Batas atas area subtitel: ${seekTop.progress}%"
        tvBottom.text = "Batas bawah area subtitel: ${seekBottom.progress}%"
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
        }
    }
}
