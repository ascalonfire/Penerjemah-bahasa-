package com.example.subtitletranslator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_START)
                    .putExtra(ScreenTranslateService.EXTRA_CODE, result.resultCode)
                    .putExtra(ScreenTranslateService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, intent)
            } else {
                Toast.makeText(this, "Izin tangkap layar ditolak", Toast.LENGTH_SHORT).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val prefs = getSharedPreferences(ScreenTranslateService.PREFS, MODE_PRIVATE)
        val group = findViewById<RadioGroup>(R.id.rgLang)
        group.check(
            when (prefs.getString(ScreenTranslateService.KEY_LANG, "latin")) {
                "zh" -> R.id.rbZh
                "ja" -> R.id.rbJa
                "ko" -> R.id.rbKo
                else -> R.id.rbLatin
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val lang = when (id) {
                R.id.rbZh -> "zh"
                R.id.rbJa -> "ja"
                R.id.rbKo -> "ko"
                else -> "latin"
            }
            prefs.edit().putString(ScreenTranslateService.KEY_LANG, lang).apply()
            Toast.makeText(this, "Tekan Berhenti lalu Mulai lagi agar bahasa berlaku", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnOverlay).setOnClickListener { requestOverlayPermission() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan overlay dulu", Toast.LENGTH_SHORT).show()
                requestOverlayPermission()
                return@setOnClickListener
            }
            val mpm = getSystemService(MediaProjectionManager::class.java)
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }

        findViewById<Button>(R.id.btnArea).setOnClickListener {
            startService(
                Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_TOGGLE_BOX)
            )
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, ScreenTranslateService::class.java)
                    .setAction(ScreenTranslateService.ACTION_STOP)
            )
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
        }
    }
}
