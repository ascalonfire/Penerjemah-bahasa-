package com.example.subtitletranslator

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OcrProcessor {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /** callback null = OCR gagal. Dipanggil di main thread. */
    fun recognize(bitmap: Bitmap, callback: (String?) -> Unit) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { text ->
                callback(text.textBlocks.joinToString(" ") { it.text })
            }
            .addOnFailureListener { callback(null) }
    }

    fun close() = recognizer.close()
}
